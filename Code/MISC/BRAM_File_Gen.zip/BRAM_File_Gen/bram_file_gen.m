f1 = fopen('init_bram.txt','w+');

for i=1:1:64 
    d1 = randperm(255,1);
    fprintf(f1,'%02X\n',d1);
end

fclose(f1);